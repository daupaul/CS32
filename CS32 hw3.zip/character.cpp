#include <iostream>
#include <string>
using namespace std;

class Character
{
public:
	Character(string name)
	{
		m_name = name;
	}
	string name() const
	{
		return m_name;
	}
	virtual void printWeapon() const = 0;
	virtual string attackAction() const = 0;
	virtual ~Character()
	{
		m_name = ""; 
	}
private:
	string m_name;
};

class Dwarf :public Character
{
public:
	Dwarf(string name) :Character(name)
	{
		m_weapon = "an axe";
	}
	virtual void printWeapon() const
	{
		cout << m_weapon;
	}
	virtual string attackAction() const
	{
		return "rushes toward the enemy";
	}
	virtual ~Dwarf()
	{
		cout << "Destroying " << name() << " the dwarf" << endl;
	}
private:
	string m_weapon;
};

class Elf :public Character
{
public:
	Elf(string name, int number) :Character(name)
	{
		m_weapon = "a bow and quiver ";
		m_quiver = number;
	}
	virtual void printWeapon() const
	{
		cout << m_weapon << "of " << m_quiver << " arrows";
	}
	virtual string attackAction() const
	{
		return "rushes toward the enemy";
	}
	virtual ~Elf()
	{
		cout << "Destroying " << name() << " the elf" << endl;
	}
private:
	string m_weapon;
	int m_quiver;
};

class Boggie :public Character
{
public:
	Boggie(string name) :Character(name)
	{
		m_weapon = "a short sword";
	}
	virtual void printWeapon() const
	{
		cout << m_weapon;
	}
	virtual string attackAction() const
	{
		return "whimpers";
	}
	virtual ~Boggie()
	{
		cout << "Destroying " << name() << " the boggie" << endl;
	}
private:
	string m_weapon;
};

void strike(const Character* cp)
{
	cout << cp->name() << ", wielding ";
	cp->printWeapon();
	cout << ", " << cp->attackAction() << "." << endl;
}

int main()
{
	Character* characters[4];
	characters[0] = new Dwarf("Gimlet");
	// Elves have a name and initial number of arrows in their quiver
	characters[1] = new Elf("Legolam", 10);
	characters[2] = new Boggie("Frito");
	characters[3] = new Boggie("Spam");

	cout << "The characters strike!" << endl;
	for (int k = 0; k < 4; k++)
		strike(characters[k]);

	// Clean up the characters before exiting
	cout << "Cleaning up" << endl;
	for (int k = 0; k < 4; k++)
		delete characters[k];
}