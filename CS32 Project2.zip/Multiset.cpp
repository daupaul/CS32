#include "Multiset.h"
#include <iostream>

Multiset::Multiset() //constructor 
{
	m_head = nullptr;
	m_number = 0;
	m_uninumber = 0;
}

Multiset::Multiset(const Multiset &old) //copy constructor
{
	m_number = old.m_number;  //set private member to be the same
	m_uninumber = old.m_uninumber;
	item* head = new item; //set head to be the same
	head->count = old.m_head->count;
	head->text = old.m_head->text;
	head->next = nullptr;
	head->prev = nullptr;
  	m_head = head;
	item* ptr = m_head;
	for (int k = 1; k != old.uniqueSize(); k++) //set rest of the list to be the same
	{
		item* copy = new item;
		ItemType data;
		copy->count = old.get(k, data);
		copy->text = data;
		copy->next = nullptr;
		copy->prev = ptr;
		ptr->next = copy;
		ptr = copy;
	}
}

Multiset& Multiset::operator=(const Multiset &other)
{
	if (&other == this) //if they are the same then make no change
		return (*this);
	item* byebye = m_head; //delete the original list
	while (byebye != nullptr)
	{
		item* wait = byebye->next;
		delete byebye;
		byebye = wait;
	}
	m_number = other.m_number; //set private member to be the same	
	m_uninumber = other.m_uninumber;
	item* head = new item; //set head to be the same
	head->count = other.m_head->count;
	head->text = other.m_head->text;
	head->next = nullptr;
	head->prev = nullptr;
	m_head = head;
	item* ptr = m_head;
	for (int k = 1; k != other.uniqueSize(); k++) //set rest of the list to be the same
	{
		item* copy = new item;
		ItemType data;
		copy->count = other.get(k, data);
		copy->text = data;
		copy->next = nullptr;
		copy->prev = ptr;
		ptr->next = copy;
		ptr = copy;
	}
	return (*this);
}

Multiset::~Multiset()
{
	item* byebye = m_head; //delete the list
	while (byebye != nullptr)
	{
		item* wait = byebye->next;
		delete byebye;
		byebye = wait;
	}
}

bool Multiset::empty() const
{
	if (m_number == 0) //if there is nothing in the list
		return true;
	return false;
}

int Multiset::size() const
{
	return m_number;
}

int Multiset::uniqueSize() const
{
	return m_uninumber;
}

bool Multiset::insert(const ItemType& value)
{
	if (empty()) //if this is the first item, create a head
	{
		item* target = new item;
		target->text = value;
		target->count = 1;
		m_number++;
		m_uninumber++;
		target->next = nullptr;
		target->prev = nullptr;
		m_head = target;
		return true;
	}

	item* ptr;
	ptr = m_head;
	while (ptr != nullptr) 
	{
		if (ptr->text == value) //if there is any same item in the list
		{
			ptr->count++; //increase the count by 1
			m_number++;
			return true;
		}
		if (ptr->next == nullptr) //if there isn't any same item in the list
			break; //point to the last item in the list
		ptr = ptr->next;
	}
	item* target = new item; //create a new item and put it in the last of the list
	target->text = value;
	target->count = 1;
	target->prev = ptr;
	target->next = nullptr;
	ptr->next = target;
	m_number++;
	m_uninumber++;
	return true;
}

int Multiset::erase(const ItemType& value)
{
	item* ptr;
	ptr = m_head;
	while (ptr != nullptr)
	{
		if (ptr->text == value) //if value is in the list
		{
			if (ptr->count > 1) //if the count is more than one
			{
				ptr->count--; //decrease the item by 1
				m_number--;
				return 1;
			}
			else //if the count is 1
			{
				if (ptr == m_head) //if this is the head of the list
				{
					m_head = m_head->next; //set head to be the next item
					if (m_number != 1) //if this target is the last item in the list, there will not be prev since m_head is nullptr
						m_head->prev = nullptr;
					delete ptr; //delete the original head
					m_number--;
					m_uninumber--;
				}
				else //if this is not the head
				{
					item* target = ptr;
					ptr = target->prev; //point to the previous item
					ptr->next = target->next; //jump through this target
					if (target->next != nullptr) //if target is the last item of the list, then the next item will not have prev
						target->next->prev = ptr;
					delete target;
					m_number--;
					m_uninumber--;
				}
				return 1;
			}
		}
		else
			ptr = ptr->next;
	}
	return 0; //if there is no value in the list 
}

int Multiset::eraseAll(const ItemType& value)
{
	item* ptr;
	int n_erased = 0; //number of item erased
	ptr = m_head;
	while (ptr != nullptr)
	{
		if (ptr->text == value) //if value is in the list
		{
			if (ptr == m_head) //if this item is the head of the list
			{
				m_head = m_head->next; //set head to be the next item
				if (uniqueSize() != 1)
					m_head->prev = nullptr;
				n_erased = ptr->count;
				delete ptr; //delete the original head
				m_number -= n_erased;
				m_uninumber--;
			}
			else //if this is not the head of the list
			{
				item* target = ptr;
				ptr = target->prev; //point to the previous item
				ptr->next = target->next; //jump through this target
				if (target->next != nullptr) //if target is the last item of the list, then the next item will not have prev
					target->next->prev = ptr;
				n_erased = target->count;
				delete target;
				m_number -= n_erased;
				m_uninumber--;
			}
			return n_erased;
		}
		else
			ptr = ptr->next;
	}
	return n_erased; //if value is not in the list
}

bool Multiset::contains(const ItemType& value) const
{
	item* ptr;
	ptr = m_head;
	while (ptr != nullptr)
	{
		if (ptr->text == value) //if value is in the list
			return true;
		ptr = ptr->next;
	}
	return false;
}

int Multiset::count(const ItemType& value) const
{
	item* ptr;
	ptr = m_head;
	while (ptr != nullptr)
	{
		if (ptr->text == value) //if value is in the list
			return ptr->count;
		ptr = ptr->next;
	}
	return 0;
}

int Multiset::get(int i, ItemType& value) const
{
	if (i < 0 || i >= uniqueSize()) //if i does not match the requirement 
		return 0;
	int number = i;
	item* ptr;
	ptr = m_head;
	while (ptr != nullptr)
	{
		if (number == 0)
		{
			value = ptr->text;
			return ptr->count;
		}
		else
		{
			number--; //loop to the i-th item in the list
			ptr = ptr->next;
		}
	}
	return 0;
}

void Multiset::swap(Multiset& other)
{
	Multiset copy(other); //make a copy of other
	other = *this;
	*this = copy;
}

void combine(const Multiset& ms1, const Multiset& ms2, Multiset& result)
{
	result = ms1;
	ItemType add;
	int number;
	for (int k = 0; k != ms2.uniqueSize(); k++)
	{
		number = ms2.get(k, add); //find the text and count in ms2
		for (int i = 0; i != number; i++) //insert number times if add has more than 1
			result.insert(add);
	}
}

void subtract(const Multiset& ms1, const Multiset& ms2, Multiset& result)
{
	result = ms1;
	ItemType byebye;
	int number;
	for (int k = 0; k != ms2.uniqueSize(); k++)
	{
		number = ms2.get(k, byebye); //find the text and count in ms2
		for (int i = 0; i != number; i++) //delete number times if add has more than 1
			result.erase(byebye);
	}
}