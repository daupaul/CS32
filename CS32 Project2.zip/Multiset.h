#ifndef MULTISET_INCLUDED
#define MULTISET_INCLUDED
#include<string>
typedef std::string ItemType;

class Multiset
{
public:
	Multiset();
	Multiset(const Multiset &old);
	Multiset& operator=(const Multiset &other);
	~Multiset();
	bool empty() const;
	int size() const;
	int uniqueSize() const;
	bool insert(const ItemType& value);
	int erase(const ItemType& value);
	int eraseAll(const ItemType& value);
	bool contains(const ItemType& value) const;
	int count(const ItemType& value) const;
	int get(int i, ItemType& value) const;
	void swap(Multiset& other);
private:
	struct item
	{
		ItemType text;
		int count;
		item* next;
		item* prev;
	};
	item* m_head;
	int m_number;
	int m_uninumber;
};

void combine(const Multiset& ms1, const Multiset& ms2, Multiset& result);
void subtract(const Multiset& ms1, const Multiset& ms2, Multiset& result);
#endif