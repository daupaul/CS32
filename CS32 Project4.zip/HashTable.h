#ifndef HASHTABLE_H
#define HASHTABLE_H

template <typename KeyType, typename ValueType>
class HashTable
{
public:
	HashTable(unsigned int numBuckets, unsigned int capacity);
	~HashTable();
	bool isFull()	const;
	bool set(const KeyType&	key, const ValueType& value, bool permanent = false);
	bool get(const KeyType& key, ValueType& value)	const;
	bool touch(const KeyType& key);
	bool discard(KeyType& key, ValueType& value);
private:
	//	We	prevent a	HashTable from	being	copied	or	assigned	by	declaring	the
	//	copy	constructor	and	assignment	operator	private	and	not	implementing	them.
	HashTable(const HashTable&);
	HashTable& operator=(const HashTable&);
	int m_bucket;
	int m_capacity;
	struct HT
	{
		KeyType key;
		ValueType value;
		bool permanent;
		HT* next;
		HT* prev;
	};
	struct track
	{
		HT* target;
		int n;
		track* next;
		track* prev;
	};
	HT* find(const KeyType& key) const;
	HT** m_ht;
	track* m_track;
	int m_number;
};

template <typename KeyType, typename ValueType>
HashTable<KeyType, ValueType>::HashTable(unsigned int numBuckets, unsigned int capacity)
{
	m_capacity = capacity;
	m_bucket = numBuckets;
	m_ht = new HT*[m_bucket];
	m_number = 0;
	for (int k = 0; k != m_bucket; k++)
		m_ht[k] = nullptr;
	m_track = nullptr;
}

template <typename KeyType, typename ValueType>
HashTable<KeyType, ValueType>::~HashTable()
{
	for (int k = 0; k != m_bucket; k++)
	{
		while (m_ht[k] != nullptr)
		{
			HT* temp = m_ht[k];
			m_ht[k] = m_ht[k]->next;
			delete temp;
		}
	}
	while (m_track != nullptr)
	{
		track* temp = m_track;
		m_track = m_track->next;
		delete temp;
	}
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::isFull() const
{
	if (m_number == m_capacity)
		return true;
	return false;
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::set(const KeyType&	key, const ValueType& value, bool permanent)
{
	HT* target = find(key);
	if (target == nullptr && isFull())
		return false;
	unsigned int computeHash(KeyType); // prototype
	unsigned int hash = computeHash(key);
	unsigned int bucket = hash % m_bucket;
	if (target != nullptr)
	{
		if (target->prev != nullptr)
			target->prev->next = target->next;
		if (target->next != nullptr)
			target->next->prev = target->prev;
		permanent = target->permanent;
		if (target == m_ht[bucket])
			m_ht[bucket] = m_ht[bucket]->next;
		delete target;
		m_number--;
	}
	HT* ptr = m_ht[bucket];
	if (ptr != nullptr)
	{
		while (ptr->next != nullptr)
			ptr = ptr->next;
	}
	HT* add = new HT;
	add->key = key;
	add->value = value;
	add->next = nullptr;
	add->prev = ptr;
	add->permanent = permanent;
	if (ptr == nullptr)
		m_ht[bucket] = add;
	else
		ptr->next = add;
	if (!permanent)
	{
		track* byebye = m_track;
		while (byebye != nullptr)
		{
			if (byebye->target->key == key)
			{
				if (byebye->prev != nullptr)
					byebye->prev->next = byebye->next;
				if (byebye->next != nullptr)
					byebye->next->prev = byebye->prev;
				if (byebye == m_track)
					m_track = byebye->next;
				delete byebye;
				break;
			}
			byebye = byebye->next;
		}
		track* p_track = new track;
		p_track->next = m_track;
		p_track->prev = nullptr;
		p_track->n = bucket;
		p_track->target = add;
		if (m_track != nullptr)
			m_track->prev = p_track;
		m_track = p_track;
	}
	m_number++;
	return true;
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::get(const KeyType& key, ValueType& value) const
{
	HT* target = find(key);
	if (target == nullptr)
		return false;
	value = target->value;
	return true;
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::touch(const KeyType& key)
{
	HT* target = find(key);
	if (target == nullptr || target->permanent == true)
		return false;
	ValueType value;
	get(key, value);
	set(key, value);
	return true;
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::discard(KeyType& key, ValueType& value)
{
	if (m_track == nullptr)
		return false;
	track* p_track = m_track;
	while (p_track->next != nullptr)
		p_track = p_track->next;
	int bucket = p_track->n;
	if (p_track->prev != nullptr)
		p_track->prev->next = p_track->next;
	delete p_track;
	HT* temp = m_ht[bucket];
	m_ht[bucket] = m_ht[bucket]->next;
	key = temp->key;
	value = temp->value;
	delete temp;
	m_number--;
	return true;
}

template <typename KeyType, typename ValueType>
typename HashTable<KeyType, ValueType>::HT* HashTable<KeyType, ValueType>::find(const KeyType& key) const
{
	unsigned int computeHash(KeyType); // prototype
	unsigned int hash = computeHash(key);
	unsigned int bucket = hash % m_bucket;
	HT* ptr = m_ht[bucket];
	while (ptr != nullptr)
	{
		if (ptr->key == key)
			return ptr;
		ptr = ptr->next;
	}
	return nullptr;
}

#endif
