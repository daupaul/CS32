#include "provided.h"
#include "HashTable.h"

#include <string>
#include <vector>
using namespace std;

unsigned int computeHash(std::string key)
{
	int total = 0;
	for (int k = 0; k != key.size(); k++)
		total += key[k];
	return total;
}

unsigned int computeHash(unsigned short key)
{
	return key;
}

void Compressor::compress(const string& s, vector<unsigned short>& numbers)
{
	int capacity;
	if (s.size() / 2 + 512 < 16384)
		capacity = s.size() / 2 + 512;
	else
		capacity = 16384;
	HashTable<string, unsigned short> hash(capacity * 2, capacity);
	for (int k = 0; k < 256; k++)
	{
		string a(1, static_cast<char>(k));
		hash.set(a, k, true);
	}
	int nextFreeID = 256;
	string runSoFar = "";
	vector<unsigned short> result;
	for (int k = 0; k < s.size(); k++)
	{
		string expandedRun = runSoFar + s[k];
		unsigned short value;
		if (hash.get(expandedRun, value))
			runSoFar = expandedRun;
		else
		{
			hash.get(runSoFar, value);
			result.push_back(value);
			hash.touch(runSoFar);
			runSoFar = "";
			string b = "";
			b += s[k];
			hash.get(b, value);
			result.push_back(value);
			if (hash.isFull())
			{
				unsigned short byebye;
				string key;
				hash.discard(key, byebye);
				hash.set(expandedRun, byebye);
			}
			else
			{
				hash.set(expandedRun, nextFreeID);
				nextFreeID++;
			}
		}
	}
	if (!runSoFar.empty())
	{
		unsigned short value;
		hash.get(runSoFar, value);
		result.push_back(value);
	}
	result.push_back(capacity);
	numbers = result;
}

bool Compressor::decompress(const vector<unsigned short>& numbers, string& s)
{
	if (numbers.size() <= 0)
		return false;
	int capacity = numbers[numbers.size() - 1];
	HashTable<unsigned short, string> hash(capacity * 2, capacity);
	for (int k = 0; k < 256; k++)
	{
		string a(1, static_cast<char>(k));
		hash.set(k, a, true);
	}
	int nextFreeID = 256;
	string runSoFar = "";
	string output = "";
	for (int k = 0; k < numbers.size() - 1; k++)
	{
		if (numbers[k] < 256)
		{
			string b;
			hash.get(numbers[k], b);
			output += b;
			if (runSoFar.empty())
				runSoFar += b;
			else
			{
				string expandedRun = runSoFar + b;
				if (!hash.isFull())
				{
					hash.set(nextFreeID, expandedRun);
					nextFreeID++;
				}
				else
				{
					unsigned short key;
					string c;
					hash.discard(key, c);
					hash.set(key, expandedRun);
				}
				runSoFar = "";
			}
		}
		else
		{
			string b;
			if (!hash.get(numbers[k], b))
				return false;
			hash.touch(numbers[k]);
			output += b;
			runSoFar = b;
		}
	}
	s = output;
	return true;
}
