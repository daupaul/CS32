#include "provided.h"
#include <string>
using namespace std;

bool Steg::hide(const string& hostIn, const string& msg, string& hostOut)
{
	if (hostIn.empty())
		return false;
	string revised = "";
	int numline = 1;
	for (int k = 0; k < hostIn.size(); k++)
	{
		if (hostIn[k] == ' ' || hostIn[k] == '\t')
		{
			string hold = "";
			for (int i = k; i < hostIn.size(); i++)
			{
				if (hostIn[i] == ' ' || hostIn[i] == '\t')
				{
					hold += hostIn[i];
					if (i == hostIn.size() - 1)
						k = i;
				}
				else if (hostIn[i] == '\n')
				{
					k = i - 1;
					break;
				}
				else
				{
					if (hostIn[k - 1] != '\n')
						revised += hold;
					k = i - 1;
					break;
				}
			}
		}
		else
		{
			if (hostIn[k] == '\n')
				numline++;
			revised += hostIn[k];
		}
	}
	vector<unsigned short> numbers;
	Compressor::compress(msg, numbers);
	string append = BinaryConverter::encode(numbers);
	string result = "";
	int first = append.size() % numline;
	int numchar = append.size() / numline;
	int track = 0;
	for (int k = 0; k < revised.size(); k++)
	{
		if (revised[k] == '\n' || k == revised.size()- 1)
		{
			if (k == revised.size() - 1 && revised[k] !='\n')
				result += revised[k];
			int times = numchar;
			if (first > 0)
				times = numchar + 1;
			for (int i = 0; i < times; i++)
			{
				result += append[track];
				track++;
			}
			first--;
			if (k == revised.size() - 1 && revised[k] == '\n')
			{
				result += revised[k];
				if (first > 0)
					times = numchar + 1;
				for (int i = 0; i < times; i++)
				{
					result += append[track];
					track++;
				}
				result += revised[k];
				break;
			}
		}
		result += revised[k];
		if (k == revised.size() - 1)
			result += '\n';
	}
	hostOut = result;
	return true;
}

bool Steg::reveal(const string& hostIn, string& msg) 
{
	string decode = "";
	for (int k = 0; k < hostIn.size(); k++)
	{
		if (hostIn[k] == ' ' || hostIn[k] == '\t')
		{
			string hold = "";
			for (int i = k; i < hostIn.size(); i++)
			{
				if (hostIn[i] == '\r')
					continue;
				else if (hostIn[i] == ' ' || hostIn[i] == '\t')
				{
					hold += hostIn[i];
					if (i == hostIn.size() - 1)
					{
						decode += hold;
						k = i;
						break;
					}
				}
				else if (hostIn[i] == '\n')
				{
					decode += hold;
					k = i;
					break;
				}
				else
				{
					k = i;
					break;
				}

			}
		}
	}
	vector<unsigned short> numbers;
	string finals;
	if (!BinaryConverter::decode(decode, numbers))
		return false;
	if (!Compressor::decompress(numbers, finals))
		return false;
	msg = finals;
	return true;
}
