#include "History.h"
#include "Pit.h"
#include <iostream>
using namespace std;

History::History(int nRows, int nCols)
{
	m_cols = nCols;
	m_rows = nRows;
	for (int k = 0; k != m_rows; k++)
		for (int i = 0; i != m_cols; i++)
			m_grid[k][i] = '.';
}

bool History::record(int r, int c)
{
	if (r <= m_rows && c <= m_cols)
	{
		if (m_grid[r-1][c-1] == '.')
			m_grid[r-1][c-1] = 'A';
		else if (m_grid[r-1][c-1] == 'Z')
			m_grid[r-1][c-1] = 'Z';
		else
			m_grid[r-1][c-1] += 1;
		return true;
	}
	return false;
}

void History::display() const
{
	for (int k = 0; k != m_rows; k++)
	{
		for (int i = 0; i != m_cols; i++)
			cout << m_grid[k][i];
		cout << endl;
	}
	cout << endl;
}



