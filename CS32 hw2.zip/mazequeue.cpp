#include <iostream>
#include <string>
#include <queue>
using namespace std;

class Coord
{
public:
	Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
{
	queue <Coord> position;
	position.push(Coord(sr, sc));
	maze[sr][sc] = 'p';
	while (position.size() != 0)
	{
		Coord current = position.front();
		position.pop();
		int c_row = current.r();
		int c_col = current.c();

		if (c_row == er && c_col == ec)
			return true;

		if (maze[c_row - 1][c_col] == '.')
		{
			position.push(Coord(c_row - 1, c_col));
			maze[c_row - 1][c_col] = 'p';
		}
		if (maze[c_row][c_col + 1] == '.')
		{
			position.push(Coord(c_row, c_col + 1));
			maze[c_row][c_col + 1] = 'p';
		}
		if (maze[c_row + 1][c_col] == '.')
		{
			position.push(Coord(c_row + 1, c_col));
			maze[c_row + 1][c_col] = 'p';
		}
		if (maze[c_row][c_col - 1] == '.')
		{
			position.push(Coord(c_row, c_col - 1));
			maze[c_row][c_col - 1] = 'p';
		}
	}
	return false;
}

int main()
{
	string maze[10] = {
		"XXXXXXXXXX",
		"X........X",
		"XX.X.XXXXX",
		"X..X.X...X",
		"X..X...X.X",
		"XXXX.XXX.X",
		"X.X....XXX",
		"X..XX.XX.X",
		"X...X....X",
		"XXXXXXXXXX"
	};

	if (pathExists(maze, 10, 10, 6, 4, 1, 1))
		cout << "Solvable!" << endl;
	else
		cout << "Out of luck!" << endl;
}