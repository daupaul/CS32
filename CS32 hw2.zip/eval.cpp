#include <iostream>
#include <string>
#include <stack>
#include <cassert>
using namespace std;

int evaluate(string infix, const bool values[], string& postfix, bool& result)
{
	char current;
	string p_infix = "";
	for (int k = 0; k != infix.size(); k++)
	{
		current = infix[k];
		if (current == ' ')
			continue;
		p_infix += current;
	}
	if (p_infix == "")
		return 1;
	int a = 0;
	int b = 0;
	for (int k = 0; k != p_infix.size(); k++)
	{
		current = p_infix[k];
		if (current >= '0' && current <= '9')
		{
			if (k != p_infix.size() - 1)
			{
				if (p_infix[k + 1] >= '0' && p_infix[k + 1] <= '9')
					return 1;
				if (p_infix[k + 1] == '(')
					return 1;
			}
		}
		else if (current == '(')
		{
			a++;
			if (k == p_infix.size() - 1)
				return 1;
			if (p_infix[k + 1] == '&' || p_infix[k + 1] == '|')
				return 1;
		}
		else if (current == ')')
			b++;
		else if (current == '!')
		{
			if (k == p_infix.size() - 1)
				return 1;
			if (p_infix[k + 1] == '&' || p_infix[k + 1] == '|' || p_infix[k + 1] == ')')
				return 1;
		}
		else if (current == '&')
		{
			if (k == 0 || k == p_infix.size() - 1)
				return 1;
			if (!(p_infix[k - 1] >= '0' && p_infix[k - 1] <= '9'))
				return 1;

		}
		else if (current == '|')
		{
			if (k == 0 || k == p_infix.size() - 1)
				return 1;
			if (!(p_infix[k - 1] >= '0' && p_infix[k - 1] <= '9'))
				return 1;
		}
		else
			continue;
	}
	if (a != b)
		return 1;

	postfix = "";
	stack <char> ops;
	for (int k = 0; k != p_infix.size(); k++)
	{
		current = p_infix[k];
		switch (current)
		{
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				postfix += current;
				break;
			case '(':
				ops.push(current);
				break;
			case ')':
				while (ops.top() != '(')
				{
					postfix += ops.top();
					ops.pop();
				}
				ops.pop();
				break;
			case '!':
			case '&':
			case '|':
				while (ops.size() != 0 && ops.top() != '(' && current >= ops.top())
				{
					postfix += ops.top();
					ops.pop();
				}
				ops.push(current);
				break;
			case ' ':
				break;
			default:
				return 1;
		}
	}
	while (ops.size() != 0)
	{
		postfix += ops.top();
		ops.pop();
	}

	if (postfix == "")
		return 1;

	stack <bool> operand;
	for (int k = 0; k != postfix.size(); k++)
	{
		current = postfix[k];
		if (current >= '0' && current <= '9')
		{
			int number = current - '0';
			operand.push(values[number]);
		}
		else
		{
			bool one = operand.top();
			operand.pop();
			if (current == '!')
			{
				one = !one;
				operand.push(one);
				continue;
			}
			bool two = operand.top();
			operand.pop();
			if (current == '&')
			{
				bool three = false;
				if (one && two)
					three = true;
				operand.push(three);
				continue;
			}
			if (current == '|')
			{
				bool three = false;
				if (one || two)
					three = true;
				operand.push(three);
				continue;
			}
		}
	}
	result = operand.top();
	return 0;
}

int main()
{
	bool ba[10] = {
		//  0      1      2      3      4      5      6      7      8      9
		true, true, true, false, false, false, true, false, true, false
	};
	string pf;
	bool answer;
	assert(evaluate("2| 3", ba, pf, answer) == 0 && pf == "23|" &&  answer);
	assert(evaluate("8|", ba, pf, answer) == 1);
	assert(evaluate("4 5", ba, pf, answer) == 1);
	assert(evaluate("01", ba, pf, answer) == 1);
	assert(evaluate("()", ba, pf, answer) == 1);
	assert(evaluate("2(9|8)", ba, pf, answer) == 1);
	assert(evaluate("2(&8)", ba, pf, answer) == 1);
	assert(evaluate("(6&(7|7)", ba, pf, answer) == 1);
	assert(evaluate("4  |  !3 & (0&3) ", ba, pf, answer) == 0
		&& pf == "43!03&&|"  &&  !answer);
	assert(evaluate("", ba, pf, answer) == 1);
	assert(evaluate(" 9  ", ba, pf, answer) == 0 && pf == "9"  &&  !answer);
	ba[2] = false;
	ba[9] = true;
	assert(evaluate("((9))", ba, pf, answer) == 0 && pf == "9"  &&  answer);
	assert(evaluate("2| 3", ba, pf, answer) == 0 && pf == "23|" &&  !answer);
	cout << "Passed all tests" << endl;
}
