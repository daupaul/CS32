#include "newMultiset.h"

Multiset::Multiset()
{
	m_item = new item[DEFAULT_MAX_ITEMS];
	m_number = 0;
	m_distinct = 0;
	m_max = DEFAULT_MAX_ITEMS;
}

Multiset::Multiset(int capacity)
{
	m_item = new item[capacity];
	m_number = 0;
	m_distinct = 0;
	m_max = capacity;
}

Multiset::Multiset(const Multiset &old)
{
	m_max = old.m_max;
	m_item = new item[m_max];
	m_distinct = old.m_distinct;
	m_number = old.m_number;
	for (int k = 0; k != m_distinct; k++)
	{
		m_item[k].text = old.m_item[k].text;
		m_item[k].count = old.m_item[k].count;
	}
}

Multiset& Multiset::operator=(const Multiset &other)
{
	if (&other == this)
		return (*this);
	delete[] m_item;
	m_max = other.m_max;
	m_item = new item[m_max];
	m_distinct = other.m_distinct;
	m_number = other.m_number;
	for (int k = 0; k != m_distinct; k++)
	{
		m_item[k].text = other.m_item[k].text;
		m_item[k].count = other.m_item[k].count;
	}
	return (*this);
}

Multiset::~Multiset()
{
	delete[] m_item;
	m_item = nullptr;
}

bool Multiset::empty() const
{
	if (m_number == 0)
		return true;
	return false;
}

int Multiset::size() const
{
	return m_number;
}

int Multiset::uniqueSize() const
{
	return m_distinct;
}

bool Multiset::insert(const ItemType& value)
{
	for (int k = 0; k != m_distinct; k++)
	{
		if (m_item[k].text == value)
		{
			m_item[k].count++;
			m_number++;
			return true;
		}
		else
			continue;
	}
	if (m_distinct == m_max)
		return false;
	m_item[m_distinct].text = value;
	m_item[m_distinct].count = 1;
	m_number++;
	m_distinct++;
	return true;
}

int Multiset::erase(const ItemType& value)
{
	for (int k = 0; k != m_distinct; k++)
	{
		if (m_item[k].text == value)
		{
			if (m_item[k].count == 1)
			{
				for (int i = k; i != m_distinct - 1; i++)
				{
					m_item[i].text = m_item[i + 1].text;
					m_item[i].count = m_item[i + 1].count;
				}
				m_number--;
				m_distinct--;
				return 1;
			}
			else
			{
				m_item[k].count--;
				m_number--;
				return 1;
			}
		}
		else
			continue;
	}
	return 0;
}

int Multiset::eraseAll(const ItemType& value)
{
	int n_erase = 0;
	for (int k = 0; k <= m_distinct; k++)
	{
		if (m_item[k].text == value)
		{
			n_erase = m_item[k].count;
			for (int i = k; i != m_distinct - 1; i++)
			{
				m_item[i].text = m_item[i + 1].text;
				m_item[i].count = m_item[i + 1].count;
			}
			m_number -= n_erase;
			m_distinct--;
		}
	}
	return n_erase;
}

bool Multiset::contains(const ItemType& value) const
{
	for (int k = 0; k != m_distinct; k++)
		if (m_item[k].text == value)
			return true;
	return false;
}

int Multiset::count(const ItemType& value) const
{
	for (int k = 0; k != m_distinct; k++)
		if (m_item[k].text == value)
			return m_item[k].count;
	return 0;
}

int Multiset::get(int i, ItemType& value) const
{
	if (i < 0 || i >= uniqueSize())
		return 0;
	value = m_item[i].text;
	return m_item[i].count;
}


void Multiset::swap(Multiset& other)
{	
	Multiset copy(other);
	other = *this;
	*this = copy;
}
