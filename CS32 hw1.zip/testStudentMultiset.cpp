#include "StudentMultiset.h"
#include <iostream>
using namespace std;

int main()
{
StudentMultiset a;
a.add(34567);
a.add(34567);
a.add(23456);
a.add(89456);
cout << a.size() << endl;
a.print();
cout << "Passed all tests" << endl;
}