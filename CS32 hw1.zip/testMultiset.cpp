#include "Multiset.h"
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
	Multiset ms;
	ms.insert("cumin");
	assert(!ms.contains(""));
	ms.insert("nutmeg");
	ms.insert("");
	ms.insert("saffron");
	assert(ms.contains(""));
	ms.erase("cumin");
	assert(ms.size() == 3 && ms.contains("saffron") && ms.contains("nutmeg") &&
		ms.contains(""));
	for (int k = 0; k < ms.uniqueSize(); k++)
	{
		string x;
		int n = ms.get(k, x);
		cout << x << " occurs " << n << " times." << endl;
	}

}