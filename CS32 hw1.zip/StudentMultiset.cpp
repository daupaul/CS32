#include "StudentMultiset.h"
#include <iostream>
using namespace std;

StudentMultiset::StudentMultiset()
{

}

bool StudentMultiset::add(ItemType id)
{
	if (student.insert(id))
		return true;
	return false;
}

int StudentMultiset::size() const
{
	return student.size();
}

void StudentMultiset::print() const
{
	ItemType target;
	for (int k = 0; k != student.uniqueSize(); k++)
		for (int i = 0; i != student.get(k, target); i++)
			cout << target << endl;
}